package com.zybooks.weighttrackingapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;


public class CreateAccountActivity extends AppCompatActivity {
    private EditText edtUsername, edtPassword, edtConfirmPassword;
    private Button btnCreateAccount;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        edtUsername = findViewById(R.id.createUsernameEditText);
        edtPassword = findViewById(R.id.createPasswordEditText);
        edtConfirmPassword = findViewById(R.id.confirmPasswordEditText);
        btnCreateAccount = findViewById(R.id.createAccountButton);

        dbHelper = new DatabaseHelper(this);

        btnCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = edtUsername.getText().toString();
                String password = edtPassword.getText().toString();
                String confirmPassword = edtConfirmPassword.getText().toString();

                if(password.equals(confirmPassword)) {
                    boolean accountCreated = dbHelper.addUser(username, password);
                    if(accountCreated) {
                        Toast.makeText(CreateAccountActivity.this, "Account Created!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(CreateAccountActivity.this, UserDashboardActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(CreateAccountActivity.this, "Error creating account.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(CreateAccountActivity.this, "Passwords do not match!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
