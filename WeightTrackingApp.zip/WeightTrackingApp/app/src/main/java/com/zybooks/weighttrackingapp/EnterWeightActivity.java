package com.zybooks.weighttrackingapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Toast;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;
import android.util.Log;

public class EnterWeightActivity extends AppCompatActivity {
    private EditText edtWeight;
    private Button btnSaveWeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_weight);

        edtWeight = findViewById(R.id.weightInputEditText);
        btnSaveWeight = findViewById(R.id.submitButton);

        btnSaveWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String weight = edtWeight.getText().toString().trim();

                if (!weight.isEmpty()) {
                    DatabaseHelper dbHelper = new DatabaseHelper(EnterWeightActivity.this);
                    SQLiteDatabase db = dbHelper.getWritableDatabase();

                    ContentValues values = new ContentValues();
                    values.put(DatabaseHelper.COLUMN_WEIGHT, weight); // Corrected column name
                    Log.d("DATABASE", "Attempting to save weight: " + weight);

                    long result = db.insert(DatabaseHelper.TABLE_USERS, null, values); // Corrected table name

                    if (result != -1) {
                        Log.d("DATABASE", "Weight saved successfully.");
                        Toast.makeText(EnterWeightActivity.this, "Weight saved successfully!", Toast.LENGTH_SHORT).show();
                    } else {
                        Log.d("DATABASE", "Error while saving weight.");
                        Toast.makeText(EnterWeightActivity.this, "Error saving weight!", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Log.d("DATABASE", "Weight input is empty.");
                    Toast.makeText(EnterWeightActivity.this, "Please enter a weight!", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}
