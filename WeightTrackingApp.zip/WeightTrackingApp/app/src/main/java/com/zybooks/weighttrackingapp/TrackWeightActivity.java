package com.zybooks.weighttrackingapp;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class TrackWeightActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_track_weight);

        DatabaseHelper dbHelper = new DatabaseHelper(this);
        String username = "logged_in_username";  // Fetch this dynamically based on your app's logic.
        float latestWeight = dbHelper.getLatestWeight(username);

        if (latestWeight != -1) {
            Toast.makeText(this, "Latest weight: " + latestWeight + " kg", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "No weight data available.", Toast.LENGTH_SHORT).show();
        }
    }
}
