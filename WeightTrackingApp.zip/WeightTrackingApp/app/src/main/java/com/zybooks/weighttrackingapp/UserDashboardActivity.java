package com.zybooks.weighttrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Toast;
import android.util.Log;

public class UserDashboardActivity extends AppCompatActivity {
    private Button btnTrackWeight, btnEnterWeight;
    private TextView currentWeightTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_dashboard);

        // Retrieve the views
        btnEnterWeight = findViewById(R.id.enterWeightButton);
        btnTrackWeight = findViewById(R.id.trackWeightButton);
        currentWeightTextView = findViewById(R.id.currentWeightTextView);

        // Get the username of the logged-in user (Assuming it's passed from previous activity)
        String loggedInUsername = getIntent().getStringExtra("USERNAME_KEY");

        if (loggedInUsername == null || loggedInUsername.trim().isEmpty()) {
            // Handle null or empty username
            Toast.makeText(this, "Error: Invalid user", Toast.LENGTH_SHORT).show();
            finish();  // Close the UserDashboardActivity
            return;
        }

        // Log the username value for debugging purposes
        Log.d("DEBUG", "Username from intent: " + loggedInUsername);

        // Fetch and display the latest weight
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        float latestWeight = dbHelper.getLatestWeight(loggedInUsername);
        if (latestWeight != -1) {
            currentWeightTextView.setText("Current Weight: " + latestWeight);
        } else {
            currentWeightTextView.setText("Current Weight: Not available");
        }

        // Set the click listener for the track weight button
        btnTrackWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UserDashboardActivity.this, TrackWeightActivity.class);
                startActivity(intent);
            }
        });

        // Set the click listener for the enter weight button
        btnEnterWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UserDashboardActivity.this, EnterWeightActivity.class);
                intent.putExtra("USERNAME_KEY", loggedInUsername);
                startActivity(intent);
            }
        });
    }
}
